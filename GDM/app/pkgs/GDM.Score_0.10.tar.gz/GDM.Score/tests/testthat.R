library(testthat)
library(GDM.Models)

test_check("GDM.Models")
