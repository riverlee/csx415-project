
test_that("Model loaded", {
  expect_is(fit,"train")
})