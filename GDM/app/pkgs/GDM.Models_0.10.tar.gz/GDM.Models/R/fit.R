#' fit: pre-built model for the gestational diabetes project 
#'
#' 
#' @section fit object:
#' The fit object is a xgbTree class
#' 
#' @docType package
#' @name fit
NULL